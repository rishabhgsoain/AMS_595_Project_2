clear; clc; close all;

% The fractal
% function determines how many rounds the Mandelbrot formula (z = z^2 + c) need for a complex number 
% {c`% to diverge.
% If it never escapes (inside the set), it returns 0.

function it = fractal(c)
    iterCap =100; % Maximum iterations that is allowed to take
    z = 0; it = 0; % Intial values that assigned
    while abs(z) <= 2 && it < iterCap
        z = z^2 + c; it = it + 1;
    end
    if it == iterCap, it = 0; end
end


% The Bisection Function%
% Bisection is the function. determines the boundary point (root) percentage 
% where the indicator function changes sign using the bisection approach.
function m = bisection(fn_f, s, e)
    tol = 1e-6; % desired value of percision
    while (e - s) > tol
        mid = (s + e) / 2;
        if fn_f(mid) * fn_f(s) < 0 
            e = mid; % when the root value lies between [s,mid] inclusive
        else 
            s = mid; %when the root value lies between [mid,e] inclusive
        end
    end
    m = (s + e) / 2; % Midpoint which is start + end and divide it by 2
    % to find the middle element this process we can say that binary search
    % or divide and conquer approach
end


% ---- The indicator_fn_at_x ----% 
% function produces a "slice" function that is vertical along a fixed x value.
% For points inside the fractal, it returns -1, whereas for points outside, it returns +1.
function fn = indicator_fn_at_x(x)
    fn = @(y) (fractal(x + 1i*y) > 0) * 2 - 1;   % +1 outside, -1 inside
end

% ---- The poly_len Function ---- 
% function uses numerical integration to calculate the curve length of a 
% polynomial y(x)% between bounds a and b.

function L = poly_len(p, a, b)
    dp = polyder(p); %This is the derivative of polynomial
    arc = @(x) sqrt(1 + (polyval(dp, x)).^2);
    L = integral(arc, a, b); % Integration
end



% Step 1: Generate boundary points
% For each x, find where the fractal boundary crosses the imaginary axis (y).
samplesN   = 1000;
xGrid      = linspace(-2, 1, samplesN);
yBoundary  = nan(1, samplesN);

for idx = 1:samplesN
    fnLine = indicator_fn_at_x(xGrid(idx));

    % Skipping the line if it starts outide the fractal value
    if fnLine(0) >= 0
        continue
    end

   % Searching for top boundary points 
    foundUpper = false;
    for yTop = [0.5, 1.0, 1.5, 2.0]
        if fnLine(yTop) > 0
            yBoundary(idx) = bisection(fnLine, 0, yTop);
            foundUpper = true;
            break
        end
    end
% Skipping if it is not found in boundary range
    if ~foundUpper

        continue
    end
end




% Step 2: Polynomial fitting
% Fit a 15th-degree polynomial through the boundary points.
keep = ~isnan(yBoundary);

% HAND-TUNE the fitting window based on your plot (adjust these two numbers if needed)
fitL = -1.5;    % left x bound you want to keep
fitR =  0.25;   % right x bound you want to keep

keep = keep & (xGrid >= fitL) & (xGrid <= fitR);   % discard flat tails before fitting

p15  = polyfit(xGrid(keep), yBoundary(keep), 15);
yFit = polyval(p15, xGrid(keep));

% Just visualizing the results
figure;
plot(xGrid(keep), yBoundary(keep), 'b.', 'DisplayName','Boundary Points'); hold on;
plot(xGrid(keep), yFit, 'r-', 'LineWidth', 1.5, 'DisplayName','Polynomial Fit');
legend; xlabel('x'); ylabel('y');
title('Fractal Boundary and Polynomial Fit');
grid on

% Step 3: Curve length computation
% Compute the length of the fitted curve between given x-limits.
leftX  = max(-1.5, min(xGrid(keep)));
rightX = min( 0.5,  max(xGrid(keep)));

%  Step 4: Verification and function testing  
% To demonstrate that each function operates as intended, do brief tests.
iterA = fractal(1 + 1.5i);   
fprintf('fractal(1+1.5i) = %d\n', iterA);
%This is Iteration B for testing and above one is iteration A for testing
iterB = fractal(0);          
fprintf('fractal(0) = %d\n', iterB);

fnDemo = indicator_fn_at_x(-0.5);
insideFlag  = fnDemo(0);
outsideFlag = fnDemo(1);
fprintf('indicator_fn_at_x(-0.5) at y=0: %d, at y=1: %d\n', insideFlag, outsideFlag);

yAtMinusHalf = bisection(fnDemo, 0, 2);
fprintf('Boundary at x=-0.5: y ≈ %.6f\n', yAtMinusHalf);

% Step 5: Conduct a fast test using a smaller sample For less points 
% (for verification), repeat the same procedure.
miniN   = 200; 
miniX = linspace(-2, 1, miniN); 
miniY = nan(1, miniN);

% We fit a simpler polynomial (degree 5) and repeat the procedure with fewer points (miniN = 200) 
% to confirm the curve length computation.  
% This makes it run more quickly and helps confirm that the length and bisection functions act consistently.
for j = 1:miniN
    f = indicator_fn_at_x(miniX(j));
    if f(0) < 0 && f(1.5) > 0
        miniY(j) = bisection(f, 0, 1.5);
    end
end

miniKeep = ~isnan(miniY);
p5   = polyfit(miniX(miniKeep), miniY(miniKeep), 5);
L5   = poly_len(p5, -1.5, 0.5);
fprintf('Curve length (degree-5 quick check) = %.4f\n', L5);

L15    = poly_len(p15, leftX, rightX);
fprintf('Curve length (degree-15, x in [%.2f, %.2f]) = %.4f\n', leftX, rightX, L15);